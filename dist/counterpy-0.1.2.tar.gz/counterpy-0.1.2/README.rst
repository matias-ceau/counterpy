Counterpy
=========

**Counterpy** is a commandline tool that generates cantus firmi by using a genetic algorithm.

`Read the Docs` <https://counterpy.readthedocs.io>_
